from generation import generate
from validation import validate


if __name__ == '__main__':
    from atp import run
    run()